%% Step 1 : Set joint angle and params for FK  
close all;
clear all; clc;
addpath(genpath("mr"));

ZERO = [0, 0, 0, 0, 0, 0];
HOME = [0, 0, -90, 0, 0, 0];


% jdx 0 : Zero Pose
% jdx 1 : Home Pose
% jdx 2 : Random Pose (-pi ~ pi)
% jdx 3 : ?ъ슜??吏?젙 angle (degree)
jdx = 1;

% Set Joint Angle
if jdx == 0
    qlist = ZERO;
elseif jdx == 1
    qlist = HOME;
elseif jdx == 2
    qlist = -180 + 2*180*rand(1,6);
elseif jdx == 3
    qlist = "Write 6 by 1 vector in degree \n Ex) [0, -15, -90, 0, -75, 0]\n";
    qlist = input(qlist);
end

    
%% Step 2 : Get Tbe(from base to EE) using FK algorithm

% Set Indy Kinematics Information 
w1 = 0.10930; w2 = 0.03110; w3 = 0.07420; w4 = 0.11430; w5 = 0.06870;
h1 = 0.2305; l1 = 0.44950; l2 = 0.26550; h2 = 0.08450; l3 = 0.230;

% 1. Zero configuration
M = [1, 0, 0, -w1+w2+w3-w4-w5; 0, 1, 0, 0 ; 0, 0, 1,h1+l1+l2+h2+l3; 0, 0, 0, 1];

% 2. Body Screw
B1 = [0;0;1;0;-w1+w2+w3-w4-w5;0];
B2 = [-1;0;0;0;(l1+l2+h2+l3);0];
B3 = [-1;0;0;0;(l2+h2+l3);0];
B4 = [0;0;1;0;-w4-w5;0];
B5 = [-1;0;0;0;l3;0];
B6 = [0;0;1;0;0;0];
Blist = [B1, B2, B3, B4, B5, B6];
    
thetalist = qlist' * pi/180;
Tbe_algo = FKinBody(M, Blist, thetalist);


%% Step 3: Get  Tbe(from base to EE) using built_in function 
%B = convertStringsToChars("indy7.urdf");
robot = importrobot("indy7.urdf");

set_joint_angle(qlist, robot);

% add tcp
tcp_body = rigidBody('tcp');
tcp_joint = rigidBodyJoint('fixed');
setFixedTransform(tcp_joint,trvec2tform([0 0 0.062]));
tcp_body.Joint = tcp_joint;
addBody(robot, tcp_body, 'indy0_link6');

config = get_config(qlist, robot);

Tbe_builtin = getTransform(robot, config, 'tcp', 'indy0_link0');

%% Step 4 :  plot 
show(robot, 'visuals', 'on', 'collisions', 'off', 'Frames', 'on')
xlim([-0.8, 0.8])
ylim([-0.8, 0.8])
zlim([0, 1.5])
view(135, 15)

disp('Using FK algorithm')
Tbe_algo
disp('Using bulit in function')
Tbe_builtin
disp('Error between Tbe_algo and Tbe_builtin');
Tbe_builtin * inv(Tbe_algo)


%% functions

function set_joint_angle(q, robot)
    n = robot.NumBodies;
    for i=1:n
        robot.Bodies{i}.Joint.HomePosition = q(i) * pi/180;
    end 
end

function config = get_config(q, robot)
    q = q * pi/180;
    n = robot.NumBodies;
    
    field = {};
    value = {};
    idx = 1;
    for i=1:n
        joint = robot.Bodies{i}.Joint;
        if ~strcmp(joint.Type, 'fixed')
            field{idx} = joint.Name;
            value{idx} = q(idx);
            idx = idx +1;
        end
        
    end
    config = struct('JointName', field, 'JointPosition', value);
end

