clear all
close all
clc

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%[Indy7]%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[Slist, Mlist, Glist, M, w, p, robot] = load_urdf("indy77.urdf",6);

%% Simulation parameter
dt = 0.01;
endTime = 7;

% Initial value setting
thetalist   = [0, 0, 0, 0, 0, 0]';
dthetalist  = [0, 0, 0, 0, 0, 0]';
prev_Xe     = [0, 0, 0, 0, 0, 0]';
count = 0;

%% PI gain
Kp = 7.*[1,1,1,1,1,1]';
Ki = 0.3.*[1,1,1,1,1,1]';

%% Trajectory Generation
method =5;



Td_1 = [0 0 -1 -0.575; 0 1 0 -0.05; 1 0 0 0.78; 0 0 0 1];
Td_2 = [0 0 -1 -0.62; 0 1 0 -0.05; 1 0 0 0.78; 0 0 0 1];
Desired_trajectory = CartesianTrajectory(M, Td_2, endTime, endTime/dt, method);
Desired_trajectory =[Desired_trajectory, CartesianTrajectory(Td_2, M, endTime, endTime/dt, method)];

% First robot trajectory after grab
Td_3 = [0 0 -1 -0.475; 0 1 0 -0.05; 1 0 0 0.85; 0 0 0 1];
Td_4 = [0 0 1 0.575; 0 1 0 -0.1; -1 0 0 0.3; 0 0 0 1];
Desired_trajectory2 = CartesianTrajectory(M, Td_4, endTime, endTime/dt, method);
Desired_trajectory2 = [Desired_trajectory2 ,CartesianTrajectory(Td_4, M, endTime, endTime/dt, method)];



Np1=2;
Np2=2;
%% Control
thetalist_list1 = Indy7_Control(endTime,dt,Np1,Desired_trajectory,Kp,Ki, M, Slist,thetalist);
thetalist_list2 = Indy7_Control(endTime,dt,Np2,Desired_trajectory2,Kp,Ki, M, Slist,thetalist);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%[Youbot]%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% ROBOT PROPERTIES:
tic
Blist = [0 0 1 0 0.033 0; 0 -1 0 -0.5076 0 0; 0 -1 0 -0.3526 0 0; 0 -1 0 -0.2176 0 0; 0 0 1 0 0 0]';
Tb0 = [1, 0, 0, 0.1662; 0, 1, 0, 0; 0, 0, 1, 0.0026; 0, 0, 0, 1];
M0e = [1 0 0 0.033; 0 1 0 0; 0 0 1 0.6546; 0 0 0 1];

l = 0.47/2;
w = 0.30/2;
r = 0.0475;
z = 0.0963;
F = (r/4) * [-1/(l + w), 1/(l + w), 1/(l + w), -1/(l + w); 1 1 1 1; -1 1 -1 1];

sizee = size(F);
m = sizee(2);
zeross = zeros(1, m);
F6 = [zeross; zeross; F; zeross];

%% FEEDFORWARD AND PI CONTROL GAINS:
delta_t = 0.01;

kp = 20;
ki = 17;
Kp = kp*eye(6);
Ki = ki*eye(6);

%% TRAJECTORY PLANNING:
Tse_initial = [0.921060994002885 0 0.389418342308651 0.829087881643154; 0 1 0 0; -0.389418342308651 0 0.921060994002885 0.648543375559790; 0 0 0 1];
Tsc_initial = [1 0 0 1; 0 1 0 0; 0 0 1 0.025; 0 0 0 1];
Tsc_final = [0 1 0 0; -1 0 0 -1; 0 0 1 0.025; 0 0 0 1];
Tce_standoff = [1 0 0 0; 0 1 0 0; 0 0 1 0.2; 0 0 0 1] * [cosd(100), 0, sind(100) 0; 0, 1, 0  0; -sind(100), 0, cosd(100), 0; 0 0 0 1];
Tce_grasp = [1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1] * [cosd(100), 0, sind(100) 0; 0, 1, 0  0; -sind(100), 0, cosd(100), 0; 0 0 0 1];

movement = TrajectoryGeneratorr(Tse_initial, Tsc_initial, Tsc_final, Tce_grasp, Tce_standoff, 1);
positionSize = size(movement);
positionSize = positionSize(1) - 1;

%% ACTUAL CONFIGURATIONS AND FEEDFORWARD AND PI CONTROL:
% Setting an initial configuration
conf1 = [0.5 0.35 0.6 0 -1.0 0.5 0.1 0 0 0 0 0];
confList(1, :) = conf1(1,:);
error = [];
error2 = [];
errorSize = size(error);
errorSize = errorSize(1);
error2Size = size(error2);
error2Size = error2Size(1);

Tsb = [cos(conf1(1)), -sin(conf1(1)), 0, conf1(2); sin(conf1(1)), cos(conf1(1)), 0, conf1(3); 0, 0, 1, z; 0, 0, 0, 1 ];
T0e = FKinBody(M0e, Blist, conf1(4:8)');
Tse = Tsb * Tb0 * T0e;
X = Tse;
Tse1 = movement(1, :);
Tse11 = [Tse1(1), Tse1(2), Tse1(3), Tse1(10); Tse1(4), Tse1(5), Tse1(6), Tse1(11); Tse1(7), Tse1(8), Tse1(9), Tse1(12); 0, 0, 0, 1];
Xd1 = Tse11;
Xerr_bracket = MatrixLog6(TransInv(X) * Xd1);
Xerr = se3ToVec(Xerr_bracket);

Xerr_integral = Xerr;
for i = 1 : positionSize
    Tse1 = movement(i, :);
    Tse2 = movement(i+1, :);
    Tse1 = [Tse1(1), Tse1(2), Tse1(3), Tse1(10); Tse1(4), Tse1(5), Tse1(6), Tse1(11); Tse1(7), Tse1(8), Tse1(9), Tse1(12); 0, 0, 0, 1];
    Tse2 = [Tse2(1), Tse2(2), Tse2(3), Tse2(10); Tse2(4), Tse2(5), Tse2(6), Tse2(11); Tse2(7), Tse2(8), Tse2(9), Tse2(12); 0, 0, 0, 1];

    Xd1 = Tse1;
    Xd2 = Tse2;

    [Vd, V, Je, controls, Xerr, Xerr_integral] = FeedbackControl(X, Xd1, Xd2, Kp, Ki, delta_t, conf1(i, 4:8), Xerr_integral);
    error(errorSize+1, :) = Xerr';
    errorSize = size(error);
    errorSize = errorSize(1);

    error2(error2Size+1, :) = Xerr_integral';
    error2Size = size(error2);
    error2Size = error2Size(1);

    conf1(i+1,:) = NextStatey(conf1(i,:), [controls(5:9)', controls(1:4)'], delta_t, 10000);
    confList(i+1, :) = conf1(i+1, :);

    phi = conf1(i+1, 1);
    x = conf1(i+1, 2);
    y = conf1(i+1, 3);
    Tsb = [cos(conf1(i+1, 1)), -sin(conf1(i+1, 1)), 0, conf1(i+1, 2); sin(conf1(i+1, 1)), cos(conf1(i+1, 1)), 0, conf1(i+1, 3); 0, 0, 1, z; 0, 0, 0, 1 ];
    T0e = FKinBody(M0e, Blist, conf1(i+1, 4:8)');
    X = Tsb*Tb0*T0e;
    Xd1 = [];
    Xd2 = [];
end

for i = 1 : positionSize + 1
    confList(i,13) = movement(i, 13);
end


wheel_velocities=confList(:,9:12);
arm_velocities=confList(:,4:8);


%% Connect to V-Rep
sim=remApi('remoteApi'); % using the prototype file (remoteApiProto.m)
sim.simxFinish(-1); % just in case, close all opened connections
clientID=sim.simxStart('127.0.0.1',19999,true,true,5000,5);

if (clientID>-1)
    disp('Connected to remote API server');

    %% Initialization
    % Retrieve Wheels Joints handles
    [returnCode_fl,wheel_joints_handle(1)]=sim.simxGetObjectHandle(clientID,'rollingJoint_fl#0',sim.simx_opmode_blocking);
    [returnCode_fr,wheel_joints_handle(2)]=sim.simxGetObjectHandle(clientID,'rollingJoint_fr#0',sim.simx_opmode_blocking);
    [returnCode_rl,wheel_joints_handle(3)]=sim.simxGetObjectHandle(clientID,'rollingJoint_rl#0',sim.simx_opmode_blocking);
    [returnCode_rr,wheel_joints_handle(4)]=sim.simxGetObjectHandle(clientID,'rollingJoint_rr#0',sim.simx_opmode_blocking);
    arm_joints_handle = [-1,-1,-1,-1,-1];
    [return_code, arm_joints_handle(1)] = sim.simxGetObjectHandle(clientID,'youBotArmJoint0#0', sim.simx_opmode_blocking);
    if (return_code == sim.simx_return_ok)
        disp(' ok.');
    end
    [return_code, arm_joints_handle(2)] = sim.simxGetObjectHandle(clientID,'youBotArmJoint1#0', sim.simx_opmode_blocking);
    if (return_code == sim.simx_return_ok)
        disp(' ok.');
    end
    [return_code, arm_joints_handle(3)] = sim.simxGetObjectHandle(clientID,'youBotArmJoint2#0', sim.simx_opmode_blocking);
    if (return_code == sim.simx_return_ok)
        disp(' ok.');
    end
    [return_code, arm_joints_handle(4)] = sim.simxGetObjectHandle(clientID,'youBotArmJoint3#0', sim.simx_opmode_blocking);
    if (return_code == sim.simx_return_ok)
        disp(' ok.');
    end
    [return_code, arm_joints_handle(5)] = sim.simxGetObjectHandle(clientID,'youBotArmJoint4#0', sim.simx_opmode_blocking);
    if (return_code == sim.simx_return_ok)
        disp(' ok.');
    end
    % Desired joint positions for initialization
    desired_arm_joint_angles = arm_velocities(1,:);

    % Initialization all arm joints
    for i = 1:5
        %sim.simxSetJointPosition(clientID, arm_joints_handle(i), desired_arm_joint_angles(i), sim.simx_opmode_streaming);
        sim.simxSetJointTargetPosition(clientID, arm_joints_handle(i), desired_arm_joint_angles(i), sim.simx_opmode_streaming);
    end

    %joints handles
    h = [0,0,0,0,0,0];
    for i=1:6
        [r, h(i)]= sim.simxGetObjectHandle(clientID, convertStringsToChars("Revolute_joint"+string(i)), sim.simx_opmode_blocking);
    end

    % n, duration has no big meaning
    n = 100;
    duration = 0.01;


    %% You can change this code ------------------------------------------
    %%%%%RUNNING PART%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %% Indy7 Control

    sim.simxSetIntegerSignal(clientID,'RG2_open',1,sim.simx_opmode_streaming);
    pause(1);
    for i=1:1:length(thetalist_list1)/2
        thetalist=thetalist_list1{i};
        for j=1:1:length(thetalist)
            sim.simxSetJointTargetPosition(clientID, h(j), thetalist(j), sim.simx_opmode_streaming);
        end
        pause(0.01);
    end
    sim.simxSetIntegerSignal(clientID,'RG2_open',0,sim.simx_opmode_streaming);
    pause(1);
    for i=length(thetalist_list1)/2+1:1:length(thetalist_list1)
        thetalist=thetalist_list1{i};
        for j=1:1:length(thetalist)
            sim.simxSetJointTargetPosition(clientID, h(j), thetalist(j), sim.simx_opmode_streaming);
        end
        pause(0.01);
    end

    sim.simxSetIntegerSignal(clientID,'RG2_open',0,sim.simx_opmode_streaming);
    pause(1);
    for i=1:1:length(thetalist_list2)/2
        thetalist=thetalist_list2{i};
        for j=1:1:length(thetalist)
            sim.simxSetJointTargetPosition(clientID, h(j), thetalist(j), sim.simx_opmode_streaming);
        end
        pause(0.01);
    end
    sim.simxSetIntegerSignal(clientID,'RG2_open',1,sim.simx_opmode_streaming);
    pause(1);
    for i=length(thetalist_list2)/2+1:1:length(thetalist_list2)
        thetalist=thetalist_list2{i};
        for j=1:1:length(thetalist)
            sim.simxSetJointTargetPosition(clientID, h(j), thetalist(j), sim.simx_opmode_streaming);
        end
        pause(0.01);
    end

    %% Wheel Control
    %         for w=1:1:length(wheel_velocities)
    %             wheel_velocity=wheel_velocities(w,:);
    %             for i = 1:4
    %                 sim.simxSetJointTargetVelocity(clientID, wheel_joints_handle(i), wheel_velocity(i), sim.simx_opmode_blocking);
    %             end
    %             pause(0.01);
    %         end


    %% Arm Control
    for a=1:1:length(arm_velocities)
        arm_velocity=arm_velocities(a,:);
        wheel_velocity=wheel_velocities(a,:);
        for i = 1:4
            sim.simxSetJointTargetPosition(clientID, arm_joints_handle(i), arm_velocity(i), sim.simx_opmode_streaming);
            sim.simxSetJointTargetVelocity(clientID, wheel_joints_handle(i), wheel_velocity(i), sim.simx_opmode_blocking);
        end
        sim.simxSetJointTargetPosition(clientID, arm_joints_handle(5), arm_velocity(5), sim.simx_opmode_streaming);
        pause(0.01);
    end
    % You can change this code ------------------------------------------

else
    disp('Failed connecting to remote API server');
end
sim.delete(); % call the destructor!
disp('Program ended');


