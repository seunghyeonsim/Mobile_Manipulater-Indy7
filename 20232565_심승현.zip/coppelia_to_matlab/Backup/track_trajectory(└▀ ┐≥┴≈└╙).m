clear all
close all
clc

[Slist, Mlist, Glist, M, w, p, robot] = load_urdf("indy77.urdf",6);
%% Indy7 Configuration
w1 = 0.10930; w2 = 0.03110; w3 = 0.07420; w4 = 0.11430; w5 = 0.06870;
h1 = 0.2305; l1 = 0.44950; l2 = 0.26550; h2 = 0.08450; l3 = 0.230;
% 1. Zero configuration
%M = [1, 0, 0, -w1+w2+w3-w4-w5; 0, 1, 0, 0 ; 0, 0, 1,h1+l1+l2+h2+l3; 0, 0, 0, 1];
% 2. Body Screw
B1 = [0;0;1;0;-w1+w2+w3-w4-w5;0];
B2 = [-1;0;0;0;(l1+l2+h2+l3);0];
B3 = [-1;0;0;0;(l2+h2+l3);0];
B4 = [0;0;1;0;-w4-w5;0];
B5 = [-1;0;0;0;l3;0];
B6 = [0;0;1;0;0;0];
Blist = [B1, B2, B3, B4, B5, B6];

S1 = [0 0 1 0 0 0]';
S2 = [-1 0 0 0 -h1 0]';
S3 = [-1 0 0 0 -l1-h1 0]';
S4 = [0 0 1 0 w1-w2-w3 0]';
S5 = [-1 0 0 0 -l1-h1-l2-h2 0]';
S6 = [0 0 1 0 w1-w2-w3+w4+w5 0]';
%Slist = [S1 S2 S3 S4 S5 S6];

%% Simulation parameter
dt = 0.01;
endTime = 5;

% Initial value setting
thetalist   = [0, 0, 0, 0, 0, 0]';
dthetalist  = [0, 0, 0, 0, 0, 0]';
prev_Xe     = [0, 0, 0, 0, 0, 0]';
prev_err_p  = [0, 0, 0]'; 
thetalist_list = {};
err_t_list     = {};
count = 0;

%% PI gain
Kp = 10.*[1,1,1,1,1,1]';
Ki = 25.*[1,1,1,1,1,1]';

%% Desired Position
T_des_1 = [1 0 0 -0.45; 0 0 -1 -0.4; 0 1 0 0.67; 0 0 0 1];
[R_des, p_des] = TransToRp(T_des_1);


%% Trajectory Generation
method =5;
Desired_trajectory = CartesianTrajectory(M, T_des_1, endTime, endTime/dt, method);

%% Control
for t = linspace(0,endTime,endTime/dt)

    % Desired trajectory
    count = 1 + count;
    traj_T = cell2mat(Desired_trajectory(count));
    [traj_R, traj_p] = TransToRp(traj_T);

    % Forward kinematics
    T = FKinSpace(M, Slist, thetalist);
    [R, p] = TransToRp(T);

    % Body jacobian
    Js = JacobianSpace(Slist, thetalist);
    invT = TransInv(T);
    Jb = Adjoint(invT)*Js;            % 6-DOF
%     Jb = [Jb(4,:); Jb(5,:); Jb(6,:)]; % 3-DOF

    % Hybrid configuration representation of Task-Space error
    err_p = traj_p - p;
    err_R = so3ToVec(MatrixLog3(R'*traj_R));
    Xe = [err_R; err_p]; 

    % Task-Space motion controller
    % [6-DOF]
    dthetalist = pinv(Jb)*(Kp.*Xe + Ki.*(prev_Xe + dt*Xe)); % 6-DOF
    prev_Xe = Xe;

    % [3-DOF]
%     dthetalist = pinv(Jb)*(Kp(4:6).*err_p + Ki(4:6).*(prev_err_p + dt*err_p)); % 3-DOF
%     prev_err_p = err_p;

    % Euler's method
    thetalist  = thetalist + dt*dthetalist;
    thetalist_list{end+1} = thetalist;
    err_t_list{end+1} = p_des - p;

end

%% Connect to V-Rep
sim=remApi('remoteApi'); % using the prototype file (remoteApiProto.m)
sim.simxFinish(-1); % just in case, close all opened connections
clientID=sim.simxStart('127.0.0.1',19999,true,true,5000,5);

if (clientID>-1)
    disp('Connected to remote API server');

    %joints handles
    h = [0,0,0,0,0,0];
    for i=1:6
        [r, h(i)]= sim.simxGetObjectHandle(clientID, convertStringsToChars("Revolute_joint"+string(i)), sim.simx_opmode_blocking);
    end

    % n, duration has no big meaning
    n = 100;
    duration = 0.01;


    % You can change this code ------------------------------------------




    for i=1:1:length(thetalist_list)
        thetalist=thetalist_list{i};
        for j=1:1:length(thetalist)
            sim.simxSetJointTargetPosition(clientID, h(j), thetalist(j), sim.simx_opmode_streaming);
        end
        pause(0.1);
    end


    % You can change this code ------------------------------------------
else
    disp('Failed connecting to remote API server');
end
sim.delete(); % call the destructor!
disp('Program ended');

%% Plot error
% task space error
err_tx = zeros(1,length(err_t_list));
err_ty = zeros(1,length(err_t_list));
err_tz = zeros(1,length(err_t_list));
time   = zeros(1,length(err_t_list));

for i = 1 : 1 : length(err_t_list)
    errlist_t = err_t_list{i};
    err_tx(i) = errlist_t(1);
    err_ty(i) = errlist_t(2);
    err_tz(i) = errlist_t(3);
    time(i)  = i*dt; 
end

f2 = figure;
subplot(3,1,1);
plot(time, err_tx)
title('X err')
ylim([-1 1])
grid on
subplot(3,1,2);
plot(time, err_ty)
title('Y err')
ylim([-1 1])
grid on
subplot(3,1,3);
plot(time, err_tz)
title('Z err')
ylim([-1 1])
grid on
sgtitle('Task space error')
