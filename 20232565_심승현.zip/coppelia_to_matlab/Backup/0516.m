clear all
close all
clc
%% Indy7 Configuration
w1 = 0.10930; w2 = 0.03110; w3 = 0.07420; w4 = 0.11430; w5 = 0.06870;
h1 = 0.2305; l1 = 0.44950; l2 = 0.26550; h2 = 0.08450; l3 = 0.230;
% 1. Zero configuration
M = [1, 0, 0, -w1+w2+w3-w4-w5; 0, 1, 0, 0 ; 0, 0, 1,h1+l1+l2+h2+l3; 0, 0, 0, 1];
% 2. Body Screw
B1 = [0;0;1;0;-w1+w2+w3-w4-w5;0];
B2 = [-1;0;0;0;(l1+l2+h2+l3);0];
B3 = [-1;0;0;0;(l2+h2+l3);0];
B4 = [0;0;1;0;-w4-w5;0];
B5 = [-1;0;0;0;l3;0];
B6 = [0;0;1;0;0;0];
Blist = [B1, B2, B3, B4, B5, B6];

S1 = [0 0 1 0 0 0]';
S2 = [-1 0 0 0 -h1 0]';
S3 = [-1 0 0 0 -l1-h1 0]';
S4 = [0 0 1 0 w1-w2-w3 0]';
S5 = [-1 0 0 0 -l1-h1-l2-h2 0]';
S6 = [0 0 1 0 w1-w2-w3+w4+w5 0]';
Slist = [S1 S2 S3 S4 S5 S6];


thetalist0 = [0 0 0 0 0 0]';
Td_1 = [1 0 0 -0.45; 0 0 -1 -0.425; 0 1 0 0.06167; 0 0 0 1];
traj = ScrewTrajectory(M, Td_1, 0.1, 10, 5);
Td_2 = [0 0 -1 -0.3; 0 1 0 0.575; 1 0 0 0; 0 0 0 1];
traj_2 = ScrewTrajectory(traj{10}, Td_2, 0.1, 10, 5);
traj(1,1:10) = traj;
%traj(1,11:20) = traj_2;
traj_len = size(traj);
traj_len = traj_len(2);
theta = zeros(6, traj_len+1);
for i = 1:traj_len
    [theta(:,i), success] = IKinSpaceGrad(Slist,M,traj{i},thetalist0,0.3,0.01, 0.01);
    thetalist0 = theta(:,i);
    %         FKinBody(M,Blist,theta(i,:))
end


%% Connect to V-Rep
sim=remApi('remoteApi'); % using the prototype file (remoteApiProto.m)
sim.simxFinish(-1); % just in case, close all opened connections
clientID=sim.simxStart('127.0.0.1',19999,true,true,5000,5);

if (clientID>-1)
    disp('Connected to remote API server');

    %joints handles
    h = [0,0,0,0,0,0];
    for i=1:6
        [r, h(i)]= sim.simxGetObjectHandle(clientID, convertStringsToChars("Revolute_joint"+string(i)), sim.simx_opmode_blocking);
    end

    % n, duration has no big meaning
    n = 100;
    duration = 0.01;


    % You can change this code ------------------------------------------




    for i=1:traj_len
        for j=1:6
            sim.simxSetJointTargetPosition(clientID, h(j), theta(j,i), sim.simx_opmode_streaming);
        end
        pause(0.1);
    end


    % You can change this code ------------------------------------------
else
    disp('Failed connecting to remote API server');
end
sim.delete(); % call the destructor!
disp('Program ended');
