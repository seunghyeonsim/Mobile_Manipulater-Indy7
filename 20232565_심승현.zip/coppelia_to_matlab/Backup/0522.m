clear all
close all
clc

[Slist, Mlist, Glist, M, w, p, robot] = load_urdf("indy77.urdf",6);

%% Simulation parameter
dt = 0.01;
endTime = 5;

% Initial value setting
thetalist   = [0, 0, 0, 0, 0, 0]';
dthetalist  = [0, 0, 0, 0, 0, 0]';
prev_Xe     = [0, 0, 0, 0, 0, 0]';
count = 0;

%% PI gain
Kp = 5.*[1,1,1,1,1,1]';
Ki = 0.5.*[1,1,1,1,1,1]';

%% Desired Position
Ang_1 = [75 -75 105];
Pos_1 = [-0.3682 -0.19915 0.6];
% T_des_1 = [-0.0773 0.0557 -0.9955 -0.575; 0.1572 0.9866 0.0430 +0.025; 0.9845 -0.1531 -0.085 +0.775; 0 0 0 1];
T_des_2 = [1 0 0 0.35; 0 0 -1 -0.4; 0 1 0 0.67; 0 0 0 1];
% T_des_3 = [1 0 0 -0.5; 0 0 -1 -0.2; 0 1 0 0.47; 0 0 0 1];
T_des_1 = eul2rotm(Ang_1);
T_des_1 = RpToTrans(T_des_1, Pos_1');
[R_des, p_des] = TransToRp(T_des_1);


%% Trajectory Generation
method =5;

Desired_trajectory1 = CartesianTrajectory(M, T_des_1, endTime, endTime/dt, method);
Desired_trajectory1 = [Desired_trajectory1, CartesianTrajectory(T_des_1, M, endTime, endTime/dt, method)];
Desired_trajectory2 = CartesianTrajectory(T_des_1, M, endTime, endTime/dt, method);

Np1=2;
Np2=1;
%% Control
thetalist_list1 = Indy7_Control(endTime,dt,Np1,Desired_trajectory1,Kp,Ki, M, Slist,thetalist);
thetalist_list2 = Indy7_Control(endTime,dt,Np2,Desired_trajectory2,Kp,Ki, M, Slist,thetalist);

%% Connect to V-Rep
sim=remApi('remoteApi'); % using the prototype file (remoteApiProto.m)
sim.simxFinish(-1); % just in case, close all opened connections
clientID=sim.simxStart('127.0.0.1',19999,true,true,5000,5);

if (clientID>-1)
    disp('Connected to remote API server');

    %joints handles
    h = [0,0,0,0,0,0];
    for i=1:6
        [r, h(i)]= sim.simxGetObjectHandle(clientID, convertStringsToChars("Revolute_joint"+string(i)), sim.simx_opmode_blocking);
    end

    % n, duration has no big meaning
    n = 100;
    duration = 0.01;


    % You can change this code ------------------------------------------


    sim.simxSetIntegerSignal(clientID,'RG2_open',1,sim.simx_opmode_streaming);
    pause(1);
    for i=1:1:length(thetalist_list1)/2
        thetalist=thetalist_list1{i};
        for j=1:1:length(thetalist)
            sim.simxSetJointTargetPosition(clientID, h(j), thetalist(j), sim.simx_opmode_streaming);
        end
        pause(0.01);
    end

    sim.simxSetIntegerSignal(clientID,'RG2_open',0,sim.simx_opmode_streaming);
    pause(1);

    for i=length(thetalist_list1)/2+1:1:length(thetalist_list1)
        thetalist=thetalist_list1{i};
        for j=1:1:length(thetalist)
            sim.simxSetJointTargetPosition(clientID, h(j), thetalist(j), sim.simx_opmode_streaming);
        end
        pause(0.01);
    end

    % You can change this code ------------------------------------------
else
    disp('Failed connecting to remote API server');
end
sim.delete(); % call the destructor!
disp('Program ended');


