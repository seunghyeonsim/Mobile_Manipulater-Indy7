function thetalist_list = Indy7_Control(endTime,dt,Np,Desired_trajectory,Kp,Ki, M, Slist,thetalist)
% Initial value setting

prev_Xe     = [0, 0, 0, 0, 0, 0]';
prev_err_p  = [0, 0, 0]';
count = 0;
thetalist_list = {};

for t = linspace(0,endTime*Np,endTime*Np/dt)
    
    % Desired trajectory
    count = 1 + count;
    traj_T = cell2mat(Desired_trajectory(count));
    [traj_R, traj_p] = TransToRp(traj_T);
    pos(count,:) = traj_p;
    
    % Forward kinematics
    T = FKinSpace(M, Slist, thetalist);
    [R, p] = TransToRp(T);

    % Body jacobian
    Js = JacobianSpace(Slist, thetalist);
    invT = TransInv(T);
    Jb = Adjoint(invT)*Js;            % 6-DOF

    % Hybrid configuration representation of Task-Space error
    err_p = traj_p - p;
    err_R = so3ToVec(MatrixLog3(R'*traj_R));
    Xe = [err_R; err_p]; 

    % Task-Space motion controller
    dthetalist = pinv(Jb)*(Kp.*Xe + Ki.*(prev_Xe + dt*Xe)); % 6-DOF
    prev_Xe = Xe;

    % Euler's method
    thetalist  = thetalist + dt*dthetalist;
    thetalist_list{end+1} = thetalist;

end
plot3(pos(:,1),pos(:,2),pos(:,3),'o-')
end