%% Indy7 Configuration
clear
w1 = 0.10930; w2 = 0.03110; w3 = 0.07420; w4 = 0.11430; w5 = 0.06870;
h1 = 0.2305; l1 = 0.44950; l2 = 0.26550; h2 = 0.08450; l3 = 0.230;
% 1. Zero configuration
M = [1, 0, 0, -w1+w2+w3-w4-w5; 0, 1, 0, 0 ; 0, 0, 1,h1+l1+l2+h2+l3; 0, 0, 0, 1];
% 2. Body Screw
B1 = [0;0;1;0;-w1+w2+w3-w4-w5;0];
B2 = [-1;0;0;0;(l1+l2+h2+l3);0];
B3 = [-1;0;0;0;(l2+h2+l3);0];
B4 = [0;0;1;0;-w4-w5;0];
B5 = [-1;0;0;0;l3;0];
B6 = [0;0;1;0;0;0];
Blist = [B1, B2, B3, B4, B5, B6];

S1 = [0 0 1 0 0 0]';
S2 = [-1 0 0 0 -h1 0]';
S3 = [-1 0 0 0 -l1-h1 0]';
S4 = [0 0 1 0 w1-w2-w3 0]';
S5 = [-1 0 0 0 -l1-h1-l2-h2 0]';
S6 = [0 0 1 0 w1-w2-w3+w4+w5 0]';
Slist = [S1 S2 S3 S4 S5 S6];

%% Trajectory Generation

thetalist0 = [0 0 0 0 0 0]';
Td_1 = [1 0 0 -0.05; 0 0 -1 -0.675; 0 1 0 0.06167; 0 0 0 1];
traj = ScrewTrajectory(M, Td_1, 0.1, 10, 5);

Td_2 = [0 0 -1 -0.750; 0 1 0 -0.20; 1 0 0 0.9; 0 0 0 1];
traj_2 = ScrewTrajectory(traj{10}, Td_2, 0.1, 10, 5);

traj(1,1:10) = traj;
%traj(1,11:20) = traj_2;
traj_len = length(traj);


%% Control
Kp = 1;
Ki = 3;
X = M;



thetalists = zeros(6, 854);
n =1;
[thetalist, success] = IKinSpaceGrad(Slist,M,traj{2},thetalist0,0.01,0.001,0.3);
traj_len
for i = 2:traj_len
    T_d =cell2mat(traj(i));
    Xe = se3ToVec(MatrixLog6(TransInv(X)*T_d));
    
    while norm(Xe) > 0.0001
        V_b = Kp*Xe + Ki*Xe*0.001;
        theta_dot = pinv(JacobianBody(Blist,thetalist))*V_b;
        thetalist = thetalist + theta_dot*0.1;
        thetalists(:,n) = thetalist;
        X = FKinBody(M,Blist,thetalist);
        pos(n+1,:) = X(1:3,4)';
        Xe = se3ToVec(MatrixLog6(TransInv(X)*T_d));
        norm(Xe);
        n = n +1;
        
    end
    i
thetal
%     [theta(:,i), success] = IKinSpaceGrad(Slist,M,traj{i},thetalist0,0.01,0.001,0.3);
   

end

n
plot3(pos(:,1),pos(:,2),pos(:,3),'o-')