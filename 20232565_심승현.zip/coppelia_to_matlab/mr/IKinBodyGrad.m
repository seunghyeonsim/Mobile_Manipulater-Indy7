function [thetalist, success] ...
         = IKinSpaceGrad(Blist, M, T, thetalist0,alpha, eomg, ev)

thetalist = thetalist0;
i = 0;
maxiterations = 100;
Tsb = FKinBody(M, Blist, thetalist);
Vs = Adjoint(Tsb) * se3ToVec(MatrixLog6(TransInv(Tsb) * T));
err = norm(Vs(1: 3)) > eomg || norm(Vs(4: 6)) > ev;
iteration=0;
while err && i < maxiterations
    iteration=iteration+1;
    thetalist = thetalist + alpha*transpose(JacobianBody(Blist, thetalist)) * Vs;
    i = i + 1;
    Tsb = FKinBody(M, Blist, thetalist);
    Vs = Adjoint(Tsb) * se3ToVec(MatrixLog6(TransInv(Tsb) * T));
    err = norm(Vs(1: 3)) > eomg || norm(Vs(4: 6)) > ev;

end
success = ~ err;

end