clear; clc;
N = 20;
Xstart = [[1, 0, 0, 0]; [0, 1, 0, 0]; [0, 0, 1, 0]; [0, 0, 0, 1]];
Xend = [[1, 0, 0, 3]; [0, 0, -1, 4]; [0, 1, 0, 0]; [0, 0, 0, 1]];
Ctra=CartesianTrajectory(Xstart,Xend,5,N,5);
Stra=ScrewTrajectory(Xstart,Xend,5,N,5);
celldisp(Ctra)
celldisp(Stra)


%plot 

scale = 0.3;
linewidth = 2;
% N = size(Ctra, 2);

hold on;
for i=1:N
    T = Ctra{i};
    plotT(T, scale, linewidth);
    T = Stra{i};
    plotT(T, scale, linewidth);
end
axis equal;
view(3);
grid on;
    


function plotT(T, scale, linewidth)
    R = T(1:3, 1:3);
    p = T(1:3, 4);
    
    
    quiver3(p(1), p(2), p(3), R(1,1), R(2,1), R(3,1), scale, 'Color', 'r', 'LineWidth', linewidth);
    quiver3(p(1), p(2), p(3), R(1,2), R(2,2), R(3,2), scale, 'Color', 'g', 'LineWidth', linewidth);
    quiver3(p(1), p(2), p(3), R(1,3), R(2,3), R(3,3), scale, 'Color', 'b', 'LineWidth', linewidth);   

end
