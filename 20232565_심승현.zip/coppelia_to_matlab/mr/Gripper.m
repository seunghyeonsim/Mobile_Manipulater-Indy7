function gripper AxisAng6(expc6)
   vrep=remApi('remoteApi');
   [r,p]
end