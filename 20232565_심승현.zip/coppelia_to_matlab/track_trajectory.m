clear all
close all
clc

[Slist, Mlist, Glist, M, w, p, robot] = load_urdf("indy77.urdf",6);

%% Simulation parameter
dt = 0.01;
endTime = 7;

% Initial value setting
thetalist   = [0, 0, 0, 0, 0, 0]';
dthetalist  = [0, 0, 0, 0, 0, 0]';
prev_Xe     = [0, 0, 0, 0, 0, 0]';
count = 0;

%% PI gain
Kp = 7.*[1,1,1,1,1,1]';
Ki = 0.3.*[1,1,1,1,1,1]';

%% Trajectory Generation
method =5;


% Move to Pick object
Td_1 = [0 0 -1 -0.575; 0 1 0 -0.05; 1 0 0 0.78; 0 0 0 1];
Td_2 = [0 0 -1 -0.62; 0 1 0 -0.05; 1 0 0 0.78; 0 0 0 1];
Desired_trajectory = CartesianTrajectory(M, Td_2, endTime, endTime/dt, method);
Desired_trajectory =[Desired_trajectory, CartesianTrajectory(Td_2, M, endTime, endTime/dt, method)];

% Move to Place object
Td_3 = [0 0 -1 -0.475; 0 1 0 -0.05; 1 0 0 0.85; 0 0 0 1];
Td_4 = [0 0 1 0.575; 0 1 0 -0.1; -1 0 0 0.3; 0 0 0 1];
Desired_trajectory2 = CartesianTrajectory(M, Td_4, endTime, endTime/dt, method);
Desired_trajectory2 = [Desired_trajectory2 ,CartesianTrajectory(Td_4, M, endTime, endTime/dt, method)];



Np1=2;
Np2=2;
%% Control
thetalist_list1 = Indy7_Control(endTime,dt,Np1,Desired_trajectory,Kp,Ki, M, Slist,thetalist);
thetalist_list2 = Indy7_Control(endTime,dt,Np2,Desired_trajectory2,Kp,Ki, M, Slist,thetalist);

%% Connect to V-Rep
sim=remApi('remoteApi'); % using the prototype file (remoteApiProto.m)
sim.simxFinish(-1); % just in case, close all opened connections
clientID=sim.simxStart('127.0.0.1',19999,true,true,5000,5);

if (clientID>-1)
    disp('Connected to remote API server');

    %joints handles
    h = [0,0,0,0,0,0];
    for i=1:6
        [r, h(i)]= sim.simxGetObjectHandle(clientID, convertStringsToChars("Revolute_joint"+string(i)), sim.simx_opmode_blocking);
    end

    % n, duration has no big meaning
    n = 100;
    duration = 0.01;


    % You can change this code ------------------------------------------


    sim.simxSetIntegerSignal(clientID,'RG2_open',1,sim.simx_opmode_streaming);
    pause(1);
    for i=1:1:length(thetalist_list1)/2
        thetalist=thetalist_list1{i};
        for j=1:1:length(thetalist)
            sim.simxSetJointTargetPosition(clientID, h(j), thetalist(j), sim.simx_opmode_streaming);
        end
        pause(0.01);
    end
    sim.simxSetIntegerSignal(clientID,'RG2_open',0,sim.simx_opmode_streaming);
    pause(1);
    for i=length(thetalist_list1)/2+1:1:length(thetalist_list1)
        thetalist=thetalist_list1{i};
        for j=1:1:length(thetalist)
            sim.simxSetJointTargetPosition(clientID, h(j), thetalist(j), sim.simx_opmode_streaming);
        end
        pause(0.01);
    end

    sim.simxSetIntegerSignal(clientID,'RG2_open',0,sim.simx_opmode_streaming);
    pause(1);
    for i=1:1:length(thetalist_list2)/2
        thetalist=thetalist_list2{i};
        for j=1:1:length(thetalist)
            sim.simxSetJointTargetPosition(clientID, h(j), thetalist(j), sim.simx_opmode_streaming);
        end
        pause(0.01);
    end
    sim.simxSetIntegerSignal(clientID,'RG2_open',1,sim.simx_opmode_streaming);
    pause(1);
        for i=length(thetalist_list2)/2+1:1:length(thetalist_list2)
        thetalist=thetalist_list2{i};
        for j=1:1:length(thetalist)
            sim.simxSetJointTargetPosition(clientID, h(j), thetalist(j), sim.simx_opmode_streaming);
        end
        pause(0.01);
    end



    % You can change this code ------------------------------------------
else
    disp('Failed connecting to remote API server');
end
sim.delete(); % call the destructor!
disp('Program ended');


